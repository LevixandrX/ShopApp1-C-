﻿using ShopApp_LAE.Forms;
using ShopTradeModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopApp_LAE
{
    public partial class MainWindow : Form
    {
        private int _itemCount = 0; // Переменная для хранения общего количества товаров
        public MainWindow(string userName, string role)
        {
            InitializeComponent();
            stripRole.Text += role; // Отображение роли пользователя в статус-баре
            stripName.Text += userName; // Отображение имени пользователя в статус-баре

            LoadAndInitData(); // Загрузка начальных данных

            // Заполнение выпадающего списка категорий
            var CategoryType = Program.Context.Categories.OrderBy(p => p.CategoryName).ToList();
            CategoryType.Insert(0, new ShopTradeModel.Category
            {
                CategoryName = "Все типы" // Добавляем опцию "Все типы" в начало списка
            });
            comboCategory.DataSource = CategoryType;
            comboCategory.DisplayMember = "CategoryName";
            comboCategory.ValueMember = "CategoryId";
        }

        // Загрузка данных о товарах и настройка таблицы
        private void LoadAndInitData()
        {
            // Соединение таблиц Goods и Categories для получения полной информации о товарах
            var currentGoods = Program.Context.Goods.Join(Program.Context.Categories, p => p.CategoryId, t => t.CategoryId,
                (p, t) => new { p.GoodId, p.GoodName, p.Price, p.Picture, p.Description, t.CategoryName, p.CategoryId }).ToList();

            dgvGoods.DataSource = currentGoods;
            dgvGoods.Columns[6].Visible = false; // Скрываем столбец CategoryId

            // Настройка заголовков столбцов таблицы
            dgvGoods.Columns[0].HeaderText = "Артикул товара";
            dgvGoods.Columns[1].HeaderText = "Название";
            dgvGoods.Columns[2].HeaderText = "Цена";
            dgvGoods.Columns[3].HeaderText = "Изображение";
            dgvGoods.Columns[4].HeaderText = "Описание";
            dgvGoods.Columns[5].HeaderText = "Категория";

            _itemCount = dgvGoods.Rows.Count;
            lblCountGood.Text = $" Результат запроса: {currentGoods.Count} записей из {_itemCount}";
        }

        // Обновление данных в таблице с учетом фильтров и сортировки
        private void UpdateData()
        {
            var currentGoods = Program.Context.Goods.Join(Program.Context.Categories, p => p.CategoryId, t => t.CategoryId,
                (p, t) => new { p.GoodId, p.GoodName, p.Price, p.Picture, p.Description, t.CategoryName, p.CategoryId }).ToList();

            // Фильтрация по категории, если выбрана не "Все типы"
            if (comboCategory.SelectedIndex > 0)
                currentGoods = currentGoods.Where(y => y.CategoryId == (comboCategory.SelectedItem as Category).CategoryId).ToList();

            // Фильтрация по поисковому запросу
            currentGoods = currentGoods.Where(p => p.GoodName.ToLower().Contains(txtSearch.Text.ToLower())).ToList();

            // Сортировка в зависимости от выбранного варианта
            if (comboSort.SelectedIndex >= 0)
            {
                if (comboSort.SelectedIndex == 0) // Цена по возрастанию
                    currentGoods = currentGoods.OrderBy(p => p.Price).ToList();
                else if (comboSort.SelectedIndex == 1) // Цена по убыванию
                    currentGoods = currentGoods.OrderByDescending(p => p.Price).ToList();
                else if (comboSort.SelectedIndex == 2) // Название по возрастанию
                    currentGoods = currentGoods.OrderBy(p => p.GoodName).ToList();
                else if (comboSort.SelectedIndex == 3) // Название по убыванию
                    currentGoods = currentGoods.OrderByDescending(p => p.GoodName).ToList();
            }
            dgvGoods.DataSource = currentGoods;

            lblCountGood.Text = $" Результат запроса: {currentGoods.Count} записей из {_itemCount}";
        }

        // Возврат к форме логина
        private void button1_Click(object sender, EventArgs e)
        {
            (this.Owner as fmLogin).Show();
            this.Close();
        }

        // Обновление данных при изменении текста поиска
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            UpdateData();
        }

        // Обновление данных при выборе категории
        private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateData();
        }

        // Обновление данных при выборе сортировки
        private void comboSort_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateData();
        }

        // Отображение информации о товаре при клике на ячейку таблицы
        private void dgvGoods_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int a = (int)dgvGoods[0, e.RowIndex].Value;
            var product = Program.Context.Goods.FirstOrDefault(p => p.GoodId == a);

            if (product == null) return;

            // Заполнение полей информацией о товаре
            lblGoodName.Text = product.GoodName;
            lblPrice.Text = $"Цена: {product.Price} руб.";
            lblDescription.Text = string.IsNullOrWhiteSpace(product.Description) ? "Нет описания" : product.Description;

            // Загрузка изображения товара или заглушки
            string placeholderPath = Path.Combine(Directory.GetCurrentDirectory(), "Images", "picture.png");
            if (string.IsNullOrWhiteSpace(product.Picture))
            {
                if (File.Exists(placeholderPath))
                    pictureGood.Image = Image.FromFile(placeholderPath);
                else
                    pictureGood.Image = Properties.Resources.computer;
            }
            else
            {
                string imageName = product.Picture;
                string imagePath = Path.Combine(Directory.GetCurrentDirectory(), imageName);
                pictureGood.Image = File.Exists(imagePath) ? Image.FromFile(imagePath) : (File.Exists(placeholderPath) ? Image.FromFile(placeholderPath) : Properties.Resources.computer);
            }
        }

        private void labelNameGood_Click(object sender, EventArgs e)
        {

        }
    }
}