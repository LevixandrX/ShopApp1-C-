﻿using System;
using ShopTradeModel;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopApp_LAE.Forms
{
    public partial class fmLogin : Form
    {
        public fmLogin()
        {
            InitializeComponent();
            this.Icon = Icon.FromHandle(Properties.Resources.computer.GetHicon()); // Установка иконки формы из ресурсов
            txtPassword.PasswordChar = '*'; // Скрытие символов пароля звездочками
            pictureBoxUnVisible.Visible = false; // Изначально скрываем иконку глаза для отображения пароля
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Text;

            // Поиск пользователя в базе данных по логину и паролю
            var user = Program.Context.Users
                .FirstOrDefault(u => u.Username == login && u.Password == password);

            if (user != null)
            {
                // Если пользователь найден, открываем главное окно с его данными
                MainWindow mainForm = new MainWindow(user.Username, user.Role);
                mainForm.Owner = this;
                mainForm.Show();
                this.Hide(); // Скрываем форму логина
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Переключение видимости пароля (показать)
        private void pictureBoxVisible_Click_1(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '\0'; // Убираем маскировку символов
            pictureBoxVisible.Visible = false;
            pictureBoxUnVisible.Visible = true;
        }

        // Переключение видимости пароля (скрыть)
        private void pictureBoxUnVisible_Click_1(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*'; // Включаем маскировку символов
            pictureBoxUnVisible.Visible = false;
            pictureBoxVisible.Visible = true;
        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}