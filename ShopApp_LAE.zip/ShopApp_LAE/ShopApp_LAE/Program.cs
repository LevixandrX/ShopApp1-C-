﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShopTradeModel;
using ShopApp_LAE.Forms;

namespace ShopApp_LAE
{
    internal static class Program
    {
        public static ShopEntities Context { get; } = new ShopEntities();

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new fmLogin());
        }
    }
}
